package facility;

import java.util.ArrayList;


public interface Facility {

    String getName();

    ArrayList<Link> getConnections();

}