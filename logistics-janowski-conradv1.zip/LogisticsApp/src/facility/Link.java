package facility;


public interface Link {


    double getDistance();

    String getCity();
}
