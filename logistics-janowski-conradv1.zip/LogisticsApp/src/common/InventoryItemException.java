package common;

public class InventoryItemException extends Exception{
    public InventoryItemException(String message) {
        super(message);
    }
}
