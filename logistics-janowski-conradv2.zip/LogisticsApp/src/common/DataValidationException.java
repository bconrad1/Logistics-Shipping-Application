package common;

public class DataValidationException extends Exception {
    public DataValidationException(String message) {
        super(message);
    }
}
