package common;

/**
 * Created by ericj on 2/6/2016.
 */
public class DataValidationException extends Exception {
    public DataValidationException(String message) {
        super(message);
    }
}
