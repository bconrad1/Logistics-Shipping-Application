package common;
public class SchedulingConflictException extends Exception {
    public SchedulingConflictException(String message) {
        super(message);
    }
}
