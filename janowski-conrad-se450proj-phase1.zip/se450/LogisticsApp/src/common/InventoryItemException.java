package common;

/**
 * Created by ericj on 2/6/2016.
 */
public class InventoryItemException extends Exception{
    public InventoryItemException(String message) {
        super(message);
    }
}
