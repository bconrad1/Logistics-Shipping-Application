import scheduling.ScheduleService;

import java.util.Set;

public class Main {


    public static void main(String[] args) {

        System.out.println(StatusReport.generateReport());

    }



}
